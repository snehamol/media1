
package com.RegisterAction;
import java.sql.Connection;
//import net.viralpatel.struts2.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterDAO {
	
	static int status=0;
	
	public static int Save(RegisterAction r) throws ClassNotFoundException,SQLException{
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = null;
		
		try{
			
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/mainproject","root","sneha");
		}catch(SQLException e){
			e.printStackTrace();
		}
		PreparedStatement preparedStatement = conn.prepareStatement("insert into register values(?,?,?,?)");
		preparedStatement.setString(1,r.getUsername());
		preparedStatement.setString(2,r.getEmail());
		preparedStatement.setString(3,r.getPassword());
		preparedStatement.setString(4,r.getCpassword());
		status=preparedStatement.executeUpdate();
		return status;
	}

}




	


