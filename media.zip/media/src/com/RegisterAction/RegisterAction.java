package com.RegisterAction;
import java.sql.SQLException;
import com.opensymphony.xwork2.ActionSupport;
@SuppressWarnings("serial")
public class RegisterAction extends ActionSupport  {
		public String UserName,Email,Password,Cpassword;
	
	public String execute() throws ClassNotFoundException,SQLException {
		int i = RegisterDAO.Save(this);
		
		if(i>0)
		{
			return "success";
			
		}
		else 
		{
			return "error";
			
		}
	}

	public String getUsername() {
		return UserName;
	}

	public void setUsername(String userName) {
		UserName = userName;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getCpassword() {
		return Cpassword;
	}

	public void setCpassword(String cpassword) {
		Cpassword = cpassword;
	}
}
	
	

	




