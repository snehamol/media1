package com.ActionLogin;
import java.sql.*;
public class RetrieveDAO {
	static int status=0;
	public static int Save(LoginAction r) throws ClassNotFoundException,SQLException
	{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=null;
			try
			{
				conn=DriverManager.getConnection ("jdbc:mysql://localhost:3307/mainproject","root","sneha");
			}catch(SQLException e)
			{
				e.printStackTrace();
			}
		
		PreparedStatement PreparedStatement =conn.prepareStatement ("select * from register where UserName=? and Password=?");
		PreparedStatement .setString(1,r.getUsername());
		 PreparedStatement .setString(2,r.getPassword());
		 ResultSet rs=PreparedStatement.executeQuery();
		 if(rs.next())
		 {
			 status=1;
			 return status;
		 }
		 else
		 {
			 status=0;
			 return status;
		 }
		 
	}
}
